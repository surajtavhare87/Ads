package ADSAssignment1;
class Node
{
    int data;
    Node next;
    Node prev;
    
    Node(int data)
    {
        this.data = data;
        this.next = this.prev = null;
    }
}

class DLL
    {
        Node start;
        int length;
        
        DLL()
        {
            this.start = null;
            this.length = 0;
        }
        
    //Insertion in Beginning
        public void insertBeg(int data)
        {
            Node newNode = new Node(data);
            if(start == null)
            {
                start = newNode;
            }
            else
            {
                start.prev = newNode;
                newNode.next = start;
                start = newNode;
            }
            length++;
        }
        
    //Insertion in End
        public void insertEnd(int data)
        {
            Node newNode = new Node(data);
            
            if(start == null)
            {
                start = newNode;
            }
            else
            {
                Node n = start;
                while(n.next != null)
                {
                    n = n.next;
                }
                n.next = newNode;
                newNode.prev = n;
            }
            length++;
        }
        
      //Insertion at Middle
        public void insertPos(int data,int pos)
        {
            if(pos == 1)
            {
                insertBeg(data);
            }
            else if(pos>length)
            {
                insertEnd(data);
            }
        
        else
        {
            int i = 1;
            Node n = start;
            while(n.next != null)
            {
                i++;
                if(i == pos)
                    break;
                n = n.next;
            }
            Node newNode = new Node(data);
            newNode.prev = n;
            newNode.next = n.next;
            n.next.prev = newNode;
            n.next = newNode;
            
            length++;
         }
        }
         //Delete at Beginning
         public void deleteBeg()
         {
             Node n = start;
             if(start == null)
             {
                 System.out.println("List Empty");
             }
             else
             {
                 start = n.next;
                 start.prev = null;
             }
             length--;
         }
         
         //Delete at End
         public void deleteEnd()
         {
             if(start == null)
                 {
                   System.out.println("List Empty");
                 }
             else
             {
                 Node n = start;
                 
                 while(n.next.next != null)
                 {
                     n = n.next;
                 }
                 
                 n.next.prev = null;
                 n.next = null;
                 length--;
             }
         }
         
         //Deletion at Middle
         public void deletePos(int pos)
         {
             if(pos < 0)
             {
                 System.out.println("Pos does not");
                 return;
             }
             if(pos == 1)
             {
                 deleteBeg();
             }
             else if(pos > length)
             {
                  deleteEnd();       
             }
             else
             {
                 int i = 1;
                 Node p = start;
                 
                 while(p.next != null)
                 {
                     i++;
                     if(i == pos)
                         break;
                     p = p.next;
                 }
                 
                 p.next.next.prev = p;
                 p.next = p.next.next;
                 length--;
             }
         }

          //Display Forward
         public void displayForward()
         {
             Node n = start;
             while(n.next != null)
             {
                 System.out.print(n.data + " --> ");
                 n = n.next;
             }
             System.out.print(n.data + "  ");
         }
         
         //Display Reverse
         public void displayBackward()
         {
             Node n = start;
             while(n.next != null)
             {
                 n = n.next;
         }
         while(n.prev != null)
         {
             System.out.print(n.data + "  <-- ");
             n = n.prev;
         }
          System.out.print(n.data + "  ");
         }
}

class DoublyLinkedList
{
    public static void main(String args[])
    {
        DLL d = new DLL();
        d.insertBeg(10);
        d.insertBeg(20);
        d.insertBeg(30);
        d.insertBeg(40);
        d.insertPos(2,4);
        d.displayForward();

        System.out.println();
        
        d.deleteEnd();
        d.deleteBeg();
        d.displayForward();
        System.out.println();
        d.displayBackward();

    }
}