package adsassignment1.SingeLinkedList;
class Single1
{
    class Node
    {
        int data;
        Node next;
        
        public Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }
    
    //Represent the head and tail of the single linked list
    public Node head = null;
    public Node tail = null;
    
    //AddNode() will add a new node to the list
    public void addNode(int data)
    {
        //Create a nw Node
        Node newNode = new Node(data);
        
        //checkif the list is empty
        if(head == null)
        {
            //If list is epty,both head and tail will point to new node
            head = newNode;
            tail = newNode;
        }
        else
        {
            //newNode will be added after tail such that tails will point to NewNode
            tail.next = newNode;
            //newNode will become new tail of the list
            tail = newNode;
            }
        }
        
    
        //display() will display all the nodes present in the list
        public void display()
        {
            //Node current will point to head
            Node current = head;
            
            if(head == null)
            {
                System.out.println("List is empty");
                return;
            }
            System.out.println("Nodes of singly Linked List");
            while(current != null)
            {
                //Prints each node by Incrementing pointer
                System.out.print(current.data + " ");
                current = current.next;
            }
            
            System.out.println();
    }
}   
  class SingleCreateAndDisplay
        {
            public static void main(String args[])
            {
               Single1 s = new Single1();
               
               //Add Nodes to the list
               s.addNode(1);
               s.addNode(2);
               s.addNode(3);
               s.addNode(4);

               //Display the nodes present in the list
               s.display();
             
            }
        }
    
