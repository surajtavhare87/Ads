package adsassignment1.SingeLinkedList;
class Single2
{
    class Node
    {
        int data;
        Node next;
        
        public Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }
    
    //Represent the head and tail of the single linked list
    public Node head = null;
    public Node tail = null;
    
    //AddNode() will add a new node to the list
    public void addtoStart(int data)  //this line change
    {
        //Create a nw Node
        Node newNode = new Node(data);
        
        //checkif the list is empty
        if(head == null)
        {
            //If list is epty,both head and tail will point to new node
            head = newNode;
            tail = newNode;
        }
        else     //this condition Change 
       {
            //Node temp will point to head  
            Node temp = head;  
            //newNode will become new head of the list  
            head = newNode;  
            //Node temp(previous head) will be added after new head  
            head.next = temp;  
            }
        }
        
    
        //display() will display all the nodes present in the list
        public void display()
        {
            //Node current will point to head
            Node current = head;
            
            if(head == null)
            {
                System.out.println("List is empty");
                return;
            }
            System.out.println("Adding Nodes Start of singly Linked List");
            while(current != null)
            {
                //Prints each node by Incrementing pointer
                System.out.print(current.data + " ");
                current = current.next;
            }
            
            System.out.println();
    }
}   
  class SingleInsertionBeg
        {
            public static void main(String args[])
            {
               Single2 s = new Single2();
               
               //Add Nodes to the list
               s.addtoStart(1);
                s.display();
               s.addtoStart(2);
                s.display();
               s.addtoStart(3);
                s.display();
               s.addtoStart(4);
                  s.display();
               
              
             
            }
        }
    
