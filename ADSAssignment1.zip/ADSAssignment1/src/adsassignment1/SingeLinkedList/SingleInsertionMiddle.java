package adsassignment1.SingeLinkedList;
class Single4
{
    class Node
    {
        int data;
        Node next;
        
        public Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }
    
    public int size;  //This change
    //Represent the head and tail of the single linked list
    public Node head = null;
    public Node tail = null;
    
    //AddNode() will add a new node to the list
    public void addtoEnd(int data)  //this line change
    {
        //Create a nw Node
        Node newNode = new Node(data);
        
        //checkif the list is empty
        if(head == null)
        {
            //If list is epty,both head and tail will point to new node
            head = newNode;
            tail = newNode;
        }
        else     //this condition Change 
       {
            //newNode will be added after tail such that tail's next will point to newNode  
            tail.next = newNode;  
            //newNode will become new tail of the list  
            tail = newNode;  
            }
        //Size willcount the number of nodes present in the List
        size++;
        }
    
    
        //This function will add the new node at the middle of the list.  
    public void addInMid(int data){  
        //Create a new node  
        Node newNode = new Node(data);  
  
        //Checks if the list is empty  
        if(head == null) {  
            //If list is empty, both head and tail would point to new node  
            head = newNode;  
            tail = newNode;  
        }  
        else {  
            Node temp, current;  
            //Store the mid position of the list  
            int count = (size % 2 == 0) ? (size/2) : ((size+1)/2);  
            //Node temp will point to head  
            temp = head;  
            current = null;  
  
            //Traverse through the list till the middle of the list is reached  
            for(int i = 0; i < count; i++) {  
                //Node current will point to temp  
                current = temp;  
                //Node temp will point to node next to it.  
                temp = temp.next;  
            }  
  
            //current will point to new node  
            current.next = newNode;  
            //new node will point to temp  
            newNode.next = temp;  
        }  
        size++;  
    }  
    
        //display() will display all the nodes present in the list
        public void display()
        {
            //Node current will point to head
            Node current = head;
            
            if(head == null)
            {
                System.out.println("List is empty");
                return;
            }
            //System.out.println("Adding Nodes End of singly Linked List");
            while(current != null)
            {
                //Prints each node by Incrementing pointer
                System.out.print(current.data + " ");
                current = current.next;
            }
            
            System.out.println();
    }
}   
  class SingleInsertionMiddle
        {
            public static void main(String args[])
            {
               Single4 s = new Single4();
               
               //Add Nodes to the list
               s.addtoEnd(1);
               s.addtoEnd(2);
               System.out.println("Oiginal List");
                s.display();
                
               //Inserting node '3' in the middle 
               s.addInMid(3);
               System.out.println("Updated List");
                s.display();
                
               //Inserting node '4' in the middle  
               s.addInMid(4);
               System.out.println("Updated List");
                  s.display();
               
              
             
            }
        }
    
