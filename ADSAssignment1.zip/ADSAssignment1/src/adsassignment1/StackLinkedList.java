//StackLinkedListImplementation
//Implement a stack using single linked list

package ADSAssignment1;
class Stack7
{
    private class Node
    {
        int data ;
        Node link;
    }
    
    Node top;
    
    //Constructor
    Stack7()
    {
        this.top = null;
    }
    
    public void push(int x)   //Insert at the Beginning
    {
        Node temp = new Node();
        
        if(temp == null)
        {
            System.out.println("Overflow");
            return;
        }
        
        //Initialize Data into temp data field
        temp.data = x;
        
        //put top reference into temp link
        temp.link = top;
        
        //update top reference
        top = temp;
    }
    
    public boolean isEmpty()
    {
        return top == null;
    }
    
    public int peek()
    {
        if(!isEmpty())
        {
            return top.data;
        }
        else
        {
            System.out.println("Stack is Empty");
            return -1;
        }
        
    }
    
    public void pop()   //Remove at the Beginning
    {
        if(top == null)
        {
            System.out.println("Stack Underflow");
            return;
        }
            top = (top).link;
    }
            
            
            
            
    public void display()
    {
        if(top == null)
        {
            System.out.println("Stack Underflow");
            return ;
        }
            else
        {
            Node temp  = top;
            while(temp != null)
            {
                System.out.print(temp.data+ " ");
                
                temp = temp.link;
            }
        }
    }
}

class StackLinkedListImplementation
{
    public static void main(String args[])
    {
        Stack7 s = new Stack7();
        s.push(11);
        s.push(12);
        s.push(13);
        s.push(14);

        s.display();
        System.out.println(" ");
        System.out.println("Peek  = " + s.peek());
        
        s.pop();
        s.pop();
        
        s.display();
        System.out.println(" ");
        System.out.println("Peek  = " + s.peek());

    }
    
    
    
    
    
    
}