package ADSAssignment1;
class Array1
{
    private long a[];   //ref to array a
    private int n;      //No of Data Items
    
    public Array1(int max)  //Constructor
    { 
        a = new long[max];  //Create the Array
        n = 0;              //No items yet
    } 
    
    //*******Find Specified Value************
    public boolean find(long searchKey)
    {
        int j;
        for(j=0;j<n;j++)     //For Each Element
            if(a[j] == searchKey)   //Found Item?
                break;
        if(j == n)            //Gone to end?
            return false;   //Yes cant find it
        else
            return true;    //No found it
        
    }                      //end find()
    
    //**********Insert*******************
    public void insert(long value)   //Put element into array
    {
        a[n] = value;   //Insert it
        n++;            //Increment Size
    }
    
    //************Delete*********************
    public boolean delete(long value)
    {
        int j;
        for(j=0;j<n;j++)   //Look for it
            if(value == a[j])
                break;
        if(j == n)    //Cant find it
            return false;
        else
        {
            for(int k = j;k<n;k++)   //Move higher ones down
                a[k] = a[k+1];
            n--;
            return true;
        }
     }  //End Delete()
    
    //***********Display*************************
    public void display()    //Display Array Contents
    {
        for(int j = 0;j<n;j++)  //For Each Element
            System.out.print(a[j]+" ");  //Display it
        System.out.println("");
     }
    
 } //End Class Array1

class ArryModularity
{
    public static void main(String args[])
    {
        int maxSize = 100;   //Array Size
        Array1 arr;       //Reference tp Array
        arr = new Array1(maxSize);  //Create the Array
        
        arr.insert(77);               // insert 10 items
      arr.insert(99);
      arr.insert(44);
      arr.insert(55);
      arr.insert(22);
      arr.insert(88);
      arr.insert(11);
      arr.insert(00);
      arr.insert(66);
      arr.insert(33);
      
      
      arr.display();   //Display Items
      
      int searchKey = 35;   //Searh for Items
      if(arr.find(searchKey))
          System.out.println(" Found " + searchKey);
      else
          System.out.println(" Cant Find " + searchKey);
      
      arr.delete(00);    //Delete 3 Items
      arr.delete(55);
      arr.delete(99);
      
      arr.display();     //Dispaly Items Again
      
    }   //End Main()
}       //End Class ArrayTest1